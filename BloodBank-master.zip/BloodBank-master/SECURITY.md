# Security Policy

## Supported Versions

This application must be supported in only android version 4.0 or later.

| Version | Supported          |
| ------- | ------------------ |
| 4.0 <   | :white_check_mark: |
| < 4.0   | :x:                |

## Reporting a Vulnerability

I have made this application for my own perspective. I've no responsibility if some one uses this in an illegal way.
